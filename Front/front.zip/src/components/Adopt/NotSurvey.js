// 분양게시판 전체보기에서 로그인 O, 선호도조사 X

function NotSurvey() {
    return (
        <div>
            <p><a href="/survey">설문조사</a>를 하면 나의 생활과 맞는 강아지를 추천해드려요!</p>
        </div>
    )
}

export default NotSurvey
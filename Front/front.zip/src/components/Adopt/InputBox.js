// 강쥐 이름, 나이, 지역 등등을 AdoptBoardCreate에서 입력할 수 있게 하는 컴포넌트

function AdoptInput(props) {
    return(
        <input type="text" ></input>
    )
}

export default AdoptInput
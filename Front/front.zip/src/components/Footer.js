import React from 'react';
import * as S from "../styled/Footer.style"

function Footer() {
  return (
    <S.FooterWrapper className='footer my-3'>
      <p>@KKOSUNNAE 데려가개</p>
    </S.FooterWrapper>
  );
}

export default Footer;

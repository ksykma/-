import React  from 'react';

const ChipRadio = ({ chip, setChip }) => {

  // 칩 등록 여부가 바뀔때마다 실행되는 함수
  const handleDogchipChange = (event) => {
    setChip(event.target.value);
  };

  return (
    <div>
      <label style={{ marginRight: '20px' }}>
        <input
          type="radio"
          value="등록"
          checked={chip === '등록'}
          onChange={handleDogchipChange}
        />
        등록
      </label>

      <label>
        <input
          type="radio"
          value="미등록"
          checked={chip === '미등록'}
          onChange={handleDogchipChange}
        />
        미등록(알 수 없음)
      </label>

    </div>
  );
};

export default ChipRadio;

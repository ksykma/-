// 미션 상세 조회할거임 .. ..-0 -;;

function MissionDetail() {
  return <div></div>;
}

export default MissionDetail;

// 입양후기 상세페이지
function ReviewBoardDetail() {
    return (
      <div>
        <h1>ReviewBoardDetail</h1>
      </div>
    );  
  }
  
  export default ReviewBoardDetail;
  
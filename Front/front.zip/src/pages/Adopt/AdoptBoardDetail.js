// 입양게시판 - 게시글 상세 조회 페이지

function AdoptBoardDetail() {
  return (
    <div>
      <h1>AdoptBoardDetail</h1>
    </div>
  );
}

export default AdoptBoardDetail;

// 채팅화면 + 강아지 상세정보 or 화상화면

function ChatVideo() {
  return <div></div>;
}

export default ChatVideo;
